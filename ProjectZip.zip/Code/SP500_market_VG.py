# -*- coding: utf-8 -*-
"""
Created on Tue Mar 27 18:48:58 2018

@author: Will Long
"""


import math
import numpy as np
import pandas as pd
import scipy.optimize as sop
import matplotlib as mpl
import scipy.stats as stats 
from matplotlib import cm
from NIG import fit_ml, pdf, pdf_one_point, cdf_one_point
import matplotlib.pyplot as plt
import csv
import datetime
from statsmodels.distributions.empirical_distribution import ECDF
mpl.rcParams['font.family'] = 'serif'
from scipy.integrate import quad
from matplotlib.ticker import LinearLocator, FormatStrFormatter
from mpl_toolkits.mplot3d import Axes3D
from VG_valuation_FFT import VG_value_call_FFT
from VG_option_valuation_FOU import VG_call_value_FOU, VG_call_value_INT
from BSM_option_valuation import BSM_call_value 
from NIG import cdf

# compare to market value

scalls = pd.read_excel('C:/Users/Will Long/Dropbox/HW Spring 2018/FINN6212/spxcalls20160331F.xlsx')
S0 = 2059.74
r = 0.05
tol = 0.2

options = scalls
'''
options1 = scalls[(np.abs(scalls['strike']-S0) / S0) < tol]

for row, option in options1.iterrows():
    e = datetime.datetime.strptime(str(option.loc['exdate']), "%Y%m%d")
    s = datetime.datetime.strptime(str(option.loc['date']), "%Y%m%d")
    if 5 < (e - s).days <= 8: options1.loc[row, 'T'] = (e - s).days / 365. 
    
    
    if 12 < (e - s).days <= 16: options1.loc[row, 'T'] = (e - s).days / 365.
    if 25 < (e - s).days <= 35: options1.loc[row, 'T'] = (e - s).days / 365.
    if 55 < (e - s).days <= 65: options1.loc[row, 'T'] = (e - s).days / 365.
    if 85 < (e - s).days <= 95: options1.loc[row, 'T'] = (e - s).days / 365.
    
    
    options1.loc[row, 'mean_offer'] = (option.loc['best_bid'] + option.loc['best_offer'])/2
   
options = options1[options1['T'] > 0]     
'''
def VG_error_function_FFT(p0):
    ''' Error Function for parameter calibration in NIG Model via
    Carr-Madan (1999) FFT approach.
    Parameters
    ==========
    sigma: float
    volatility factor in diffusion term
    lamb: float
    jump intensity
    mu: float
    expected jump size
    delta: float
    standard deviation of jump
    Returns
    =======
    RMSE: float
    root mean squared error
    ''' 
    
    sigma, theta, nu = p0
    alpha = (2/(nu*sigma**2)+theta**2/sigma**4)**0.5
    beta = theta/sigma**2
    if alpha < 0.0 or nu < 0.0 or (abs(alpha)-abs(beta)) < 0.0 or abs(alpha)-abs(beta+1)< 0.0 :
        return 500.0
    se = []
    for row, option in options.iterrows():
        
        T = option.loc['T']
        model_value = VG_value_call_FFT(S0, option.loc['strike'], T/365,
                                         r, sigma, theta, nu)
        se.append((model_value - option.loc['mean_offer']) ** 2)
    RMSE = math.sqrt(sum(se) / len(se))
    
    
    return RMSE

    
def VG_error_function_FOU(p0):
    ''' Error Function for parameter calibration in NIG Model via
    Carr-Madan (1999) FFT approach.
    Parameters
    ==========
    sigma: float
    volatility factor in diffusion term
    lamb: float
    jump intensity
    mu: float
    expected jump size
    delta: float
    standard deviation of jump
    Returns
    =======
    RMSE: float
    root mean squared error
    ''' 
    
    sigma, theta, nu = p0
    alpha = (2/(nu*sigma**2)+theta**2/sigma**4)**0.5
    beta = theta/sigma**2
    if alpha < 0.0 or nu < 0.0 or (abs(alpha)-abs(beta)) < 0.0 or abs(alpha)-abs(beta+1)< 0.0 :
        return 500.0
    se = []
    for row, option in options.iterrows():
        
        T = option.loc['T']
        model_value = VG_call_value_INT(S0, option.loc['strike'], T/365,
                                         r, sigma, theta, nu)
        se.append((model_value - option.loc['mean_offer']) ** 2)
    RMSE = math.sqrt(sum(se) / len(se))
    
    
    return RMSE

def generate_plot(opt, options):
    #
    # Calculating Model Prices
    #
    sigma, theta, nu = opt
    
    for row, option in options.iterrows():
        
        T = option.loc['T']
        options.loc[row, 'Model'] = VG_call_value_INT(S0, option.loc['strike'],
                   T/365, r, sigma, theta, nu)
    #
    # Plotting
    #
    mats = sorted(set(options['exdate']))
    options = options.set_index('strike')
    for i, mat in enumerate(mats):
        options[options['exdate'] == mat][['mean_offer', 'Model']].\
            plot(style=['b-', 'ro'], title='%s' % str(mat)[:10])
        plt.ylabel('VG option value')
        #plt.savefig('C:/Users/Will Long/Dropbox/Will Long Project Finn6212/Charts/VG_calibration_Model_3_%s.png' % i)
        


def VG_error_function_FOU_values(p0):
    ''' Error Function for parameter calibration in NIG Model via
    Carr-Madan (1999) FFT approach.
    Parameters
    ==========
    sigma: float
    volatility factor in diffusion term
    lamb: float
    jump intensity
    mu: float
    expected jump size
    delta: float
    standard deviation of jump
    Returns
    =======
    RMSE: float
    root mean squared error
    ''' 
    
    sigma, theta, nu = p0
    alpha = (2/(nu*sigma**2)+theta**2/sigma**4)**0.5
    beta = theta/sigma**2
    if alpha < 0.0 or nu < 0.0 or (abs(alpha)-abs(beta)) < 0.0 or abs(alpha)-abs(beta+1)< 0.0 :
        return 500.0
    se = []
    for row, option in options.iterrows():
        
        T = option.loc['T']
        model_value = VG_call_value_INT(S0, option.loc['strike'], T/365,
                                         r, sigma, theta, nu)
        se.append(model_value - option.loc['mean_offer'])
    
    
    
    return se

def BSM_error_function_FFT(p0):
    ''' Error Function for parameter calibration in NIG Model via
    Carr-Madan (1999) FFT approach.
    Parameters
    ==========
    sigma: float
    volatility factor in diffusion term
    lamb: float
    jump intensity
    mu: float
    expected jump size
    delta: float
    standard deviation of jump
    Returns
    =======
    RMSE: float
    root mean squared error
    ''' 
    
    var = p0
    if  var < 0.0 :
        return 500.0
    se = []
    for row, option in options.iterrows():
        
        T = option.loc['T']
        model_value = BSM_call_value(S0, option.loc['strike'], 0, T,
                                         r, var)
        se.append((model_value - option.loc['mean_offer']) ** 2)
    RMSE = math.sqrt(sum(se) / len(se))
    return RMSE

def generate_error_plot(opt, options):
    #
    # Calculating Model Prices
    #
    sigma, theta, nu = opt
    X_1w=[]; X_2w=[]; X_1m=[]; X_2m=[]; 
    Y_1w=[]; Y_2w=[]; Y_1m=[]; Y_2m=[]; 
    Z_1w=[]; Z_2w=[]; Z_1m=[]; Z_2m=[]; 
    F_1w=[]; F_2w=[]; F_1m=[]; F_2m=[]; 
    for row, option in options.iterrows():
        
        T = option.loc['T']
        model_value = VG_call_value_INT(S0, option.loc['strike'],
                   T/365, r, sigma, theta, nu)
        options.loc[row, 'Model'] = model_value 
        if 5 < T <= 8:
            X_1w.append(option.loc['strike'])
            a = (model_value - option.loc['mean_offer'])
            b = abs(model_value - option.loc['mean_offer'])/option.loc['mean_offer']
            Y_1w.append(a)
            if  b < 1: 
                F_1w.append(option.loc['strike'])
                Z_1w.append(b)
        if 12 < T <= 16:
            X_2w.append(option.loc['strike'])
            a = (model_value - option.loc['mean_offer'])
            b = abs(model_value - option.loc['mean_offer'])/option.loc['mean_offer']
            Y_2w.append(a)
            if  b < 1: 
                F_2w.append(option.loc['strike'])
                Z_2w.append(b)
        if 25 < T <= 35:
            X_1m.append(option.loc['strike'])
            a = (model_value - option.loc['mean_offer'])
            b = abs(model_value - option.loc['mean_offer'])/option.loc['mean_offer']
            Y_1m.append(a)
            if   b < 1: 
                F_1m.append(option.loc['strike'])
                Z_1m.append(b)
        if 55 < T <= 65:
            X_2m.append(option.loc['strike'])
            a = (model_value - option.loc['mean_offer'])
            b = abs(model_value - option.loc['mean_offer'])/option.loc['mean_offer']
            Y_2m.append(a)
            if b < 1:
                F_2m.append(option.loc['strike'])
                Z_2m.append(b)
        
        
    plt.subplot(211)
    plt.plot(X_1w, Y_1w, 'bo', label='One Week')
    plt.plot(X_2w, Y_2w, 'ro', label='Two Weeks')
    plt.plot(X_1m, Y_1m, 'go', label='One Month')
    plt.plot(X_2m, Y_2m, 'c+', label='Two Months')
    
    plt.legend(loc=0)
    plt.xlabel('strike $K$')
    plt.ylabel('Total Error')
    plt.subplot(212)
    plt.plot(F_1w, Z_1w, 'bo', label='One Week')
    plt.plot(F_2w, Z_2w, 'ro', label='Two Weeks')
    plt.plot(F_1m, Z_1m, 'go', label='One Month')
    plt.plot(F_2m, Z_2m, 'c+', label='Two Months')
    
    plt.legend(loc=0)
    plt.xlabel('strike $K$')
    plt.ylabel('Percent Error')
    plt.savefig('C:/Users/Will Long/Dropbox/Will Long Project Finn6212/Charts/VG_model_error')
    
    





