# Variance Gamma distribution for python
#
# =======================================================================================
#
# Parameters of NIG distribution
# c - location
# sigma - spread
# theta - asymmetry
# nu - shape
# (according to Seneta, E. (2004) Fitting the variance-gamma model to financial data)
#
# =======================================================================================
#
# Required packages: numpy, scipy
#
# =======================================================================================
#
# Functions of the module:
#
# pdf(x=0.0, c=0.0, sigma=1.0, theta=0.0, nu=1.0)
#     evaluates NIG probability density function
#
# cdf(x=0.0, c=0.0, sigma=1.0, theta=0.0, nu=1.0)
#     evaluates NIG cumulative density function
#
# rnd(n=1, c=0.0, sigma=1.0, theta=0.0, nu=1.0)
#     generates n random points from NIG distribution
#
# fit(data)
#     synonym for fit_ml(data)
#
# fit_moments(x)
#     fits the parameters of NIG distribution to a given list of points
#     via method of moments, assumes that theta is small (so theta^2 = 0)
#
# fit_ml(data)
#     fits the parameters of NIG distribution to a given list of points
#     via Maximizing the Likelihood functional
#
# =======================================================================================

import numpy as np
from scipy import special
from scipy.integrate import quad
from scipy import optimize

def pdf_one_point(x=0.0, mu=0.0, alpha=1.0, beta=0.0, delta=1.0):
	''' NIG probability density function in a point x '''
	temp1 = 1 / ( np.pi*(delta**2+(x-mu)**2)**0.5)
	temp2 = alpha*delta
	temp3 = np.exp(delta*(alpha**2-beta**2)**0.5+beta*(x-mu)) 
	temp4 = special.kv(1, alpha*(delta**2+(x-mu)**2)**0.5)
	return temp1*temp2*temp3*temp4

def pdf(x=0.0, mu=0.0, alpha=1.0, beta=0.0, delta=1.0):
	''' NIG probability density function of an array or a point x '''
	if isinstance(x, (int, float, np.double)): # works with lists and arrays
		return pdf_one_point(x, mu, alpha, beta, delta)
	else:
		return map(lambda x: pdf_one_point(x, mu, alpha, beta, delta), x)

def cdf_one_point(x=0.0, mu=0.0, alpha=1.0, beta=0.0, delta=1.0):
	''' NIG cumulative distribution function in a point x '''
	return quad(lambda x: pdf_one_point(x, mu, alpha, beta, delta), -50, x, epsabs=1e-10)[0] # todo: analytical solution?

def cdf(x=0.0, mu=0.0, alpha=1.0, beta=0.0, delta=1.0):
	''' NIG cumulative distribution function of an array or a point x '''
	if isinstance(x, (int, float,np.double)):
		return cdf_one_point(x, mu, alpha, beta, delta)
	else:
		return map(lambda x: cdf_one_point(x, mu, alpha, beta, delta), x)

def rnd(n=1, mu=0.0, alpha=1.0, beta=0.0, delta=1.0):
	''' generates n random points from NIG distribution '''
	# build grid
	eps = 10e-7
	range_left = range_right = 1
	while pdf(mu-range_left, mu, alpha, beta, delta) > eps:
		range_left *= 2
	while pdf(mu+range_right, mu, alpha, beta, delta) > eps:
		range_right *= 2
	step = (range_right + range_left) / 1000.0 # todo: change to adaptive?
	grid = np.arange(mu-range_left, mu+range_right, step)
	pdf_values = pdf(grid, mu, alpha, beta, delta)
	cdf_values = list(pdf_values)
	for i in range(1, len(cdf_values)):
		cdf_values[i] += cdf_values[i-1]
	cdf_values /= max(cdf_values)
	# select the number which probability is close to r01
	r01 = np.random.rand(n) # random values from [0, 1]
	r = np.random.rand(n)
	for k in range(n):
		i = 1
		while cdf_values[i] < r01[k]:
			i += 1
		r[k] = grid[i-1] + (grid[i] - grid[i-1]) * np.random.rand()
	if n == 1:
		return r[0]
	else:
		return list(r)

def fit_moments(x):
   '''Fits the paramaters of the NIG distribution to a given list of points'''
   a = np.mean(x)
   b = np.mean( (x-a)**2 )
   c = np.mean( (x-a)**3 ) / np.mean( (x-a)**2 )**1.5
   d = np.mean( (x-a)**4 ) / np.mean( (x-a)**2 )**2
   q = 1/(3*(d/(c**2)-4))**0.5
   alpha = (c**4*(1-q**2))/(3*q)**4
   beta = q*alpha
   delta = ((b*alpha*(1-q**2)*1.5)/q)**0.5
   mu = a - delta*q/(1-q*2)*0.5
    
    
    
	
   return (mu, alpha, beta, delta)

def neg_log_likelihood(data, par):
	''' negative log likelihood function for NIG distribution '''
	# par = array([c, sigma, theta, nu])
	if (par[3] > 0) and (par[1] > 0) and (par[1] > abs(par[2]) > 0):
		return -sum(np.log( list(pdf(data, mu=par[0], alpha=par[1], beta=par[2], delta = par[3]) )))
	else:
		return np.Inf


def fit_ml(data):
	''' fits the parameters of NIG distribution to a given list of points
		via Maximizing the Likelihood functional (=minimizing negative log likelihood)
		the initial point is chosen with fit_moments(x),
		optimization is performed using Nedler-Mead method '''
	par_init = np.array( fit_moments(data) )
	par = optimize.fmin(lambda x: neg_log_likelihood(data, x), par_init, maxiter=500)
	return tuple(par)




def fit(data):
	''' is equivalent to fit_ml '''
	return fit_ml(data)