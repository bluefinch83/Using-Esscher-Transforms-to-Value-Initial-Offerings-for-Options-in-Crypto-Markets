# -*- coding: utf-8 -*-
"""
Created on Thu Mar  1 13:27:50 2018

@author: Will Long
"""

import math
import numpy as np
import pandas as pd
import scipy.optimize as sop
import matplotlib as mpl
import scipy.stats as stats 
from matplotlib import cm
from VarGamma import fit_ml, pdf, pdf_one_point, cdf_one_point, neg_log_likelihood,fit_moments
from NIG import pdf_one_point as nig_pdf_one_point
from VG_option_valuation_FOU import VG_call_value_FOU, VG_call_value_INT
import matplotlib.pyplot as plt
import csv
import datetime
from statsmodels.distributions.empirical_distribution import ECDF
from scipy.optimize import minimize
mpl.rcParams['font.family'] = 'serif'

#Taking the raw data and getting the daily returns

ETH_raw = pd.read_excel('C:/Users/Will Long/Dropbox/HW Spring 2018/FINN6212/Project/ETH price data.xlsx')

ETH_raw['returns'] = 0.0

for row, coin in ETH_raw.iterrows():
    e = (coin['Open']-coin['Close'])/coin['Open']
    ETH_raw.loc[row, 'returns'] = e

er = ETH_raw['returns']
eth = sorted(er)
N = len(eth)

# Finding the Variance Gamma paraters 
def goal_fun(x):
    if (x[3] > 0) and (x[1] > 0) and (x[1] > abs(x[2]) > 0):
        return neg_log_likelihood(er, x)
    else:
        return np.Inf 
par_init = np.array( fit_moments(er) )
res = minimize(goal_fun, par_init, options={'disp': True}  )
par = res.x
c = par[0]
sigma = par[1]
theta = par[2]
nu = par[3]  

r=0.05
S0=866.525
def VG_RN(c, sigma, theta, nu):
    lam = 1/nu
    alpha = (2/(nu*sigma**2)+theta**2/sigma**4)**0.5
    e = np.exp((r-c)/lam)
    betaRN =  (((-2*alpha**2*e+alpha**2*e**2+alpha**2+e)**0.5)-e)/(e-1)
    sigmaRN = (abs(2/(nu*(alpha**2-betaRN**2))))**0.5
    thetaRN = betaRN*sigmaRN**2
    return [r, sigmaRN, thetaRN, nu]
RN=VG_RN(c, sigma, theta, nu)
sigmaRN =RN[1]
thetaRN =RN[2]
hess_er = res.hess_inv  
std_err =[]
for i in range(0,len(hess_er[0])):
    se=(hess_er[i][i])**0.5
    std_err.append(se)

t_value = []
for i in range(0,len(std_err)):
    t_value.append(par[i]/std_err[i])





    

# Testing the good-ness of fit. 
nk = 15 # size of each group for the chi
Xo = np.array_split(eth, nk)
Xp = []
for i in range(0, nk-1):
    xi = list(Xo[i])
    C1 = cdf_one_point(xi[0], c, sigma, theta, nu)
    C2 = cdf_one_point(xi[len(xi)-1], c, sigma, theta, nu)
    
    p = N*(C2-C1)
    Xp.append(p)
    
Xobs = []
for i in range(0, nk-1):
    p = len(list(Xo[i]))
    Xobs.append(p)
    
chi = stats.chisquare(Xobs, Xp)


# I'm not sure if I'm doing this right
cdf_eth = [cdf_one_point(x, c, sigma, theta, nu) for x in eth] 
def ecdf(x):
    xs = np.sort(x)
    ys = np.arange(1, len(xs)+1)/float(len(xs))
    return xs, ys

ecdf_eth = ecdf(eth)[1]

KS = stats.ks_2samp(ecdf_eth, cdf_eth)

#Ploting the daily returns
NormVar = np.mean( (er-np.mean(er))**2 )
NormMean = np.mean(er)
NormPar = [NormMean, NormVar]
def normpdf_one_point(x=0.0, mean=0.0, var=1.0):
    
    pi = 3.1415926
    denom = (2*pi*var)**.5
    num = math.exp(-(float(x)-float(mean))**2/(2*var))
    return num/denom

def normpdf(x=0.0, mean=0.0, var=1.0):
	''' NIG probability density function of an array or a point x '''
	if isinstance(x, (int, float, np.double)): # works with lists and arrays
		return normpdf_one_point(x, mean, var)
	else:
		return map(lambda x: normpdf_one_point(x, mean=0.0, var=1.0), x)

mu=5.02755572e-03
alpha=9.17731507
beta=-3.31953720
delta=4.73019116e-02
nbins = 30 # number of bins
bins = np.linspace(eth[0], eth[N-1], nbins)

y = [N/(nbins*2)*pdf_one_point(x, c, sigma, theta, nu) for x in eth]
plt.hist(er, bins)
plt.xlabel('Percentage')
plt.title('Daily returns of ETH from 03/01/2017 to 02/28/2018')

yn = [N/(nbins*2)*normpdf(x, NormMean, NormVar) for x in eth]
ynig = [N/(nbins*2)*nig_pdf_one_point(x, mu, alpha, beta, delta) for x in eth]

plt.hist(er, bins)
plt.plot(eth, ynig, 'b-.', lw=2.5, label='NIG') 
plt.plot(eth, yn, 'r-.', lw=2.5, label='Normal')
plt.plot(eth, y, 'c-.', lw=2.5, label='VG')
plt.legend(loc=0)
#plt.savefig('C:/Users/Will Long/Dropbox/Will Long Project Finn6212/Charts/FitETH.png')
#plt.plot(eth, y, 'b-.', lw=2.5) 
points = 100
plt.figure(2)
X=np.linspace(.8*S0, 1.2*S0, points)
YK=[VG_call_value_INT(S0, K, 7/365, r, sigmaRN, thetaRN, nu) for K in X]
plt.plot(X,YK, label='1 Week')
plt.xlabel('Strike Price')
plt.ylabel('USD')
plt.title('Call value at 02/28/2018')
plt.legend(loc=0)
#plt.savefig('C:/Users/Will Long/Dropbox/Will Long Project Finn6212/Charts/VGcallETH.png')


