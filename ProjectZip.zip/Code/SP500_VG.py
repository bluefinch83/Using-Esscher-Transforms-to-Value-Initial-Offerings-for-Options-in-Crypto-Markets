# -*- coding: utf-8 -*-
"""
Created on Thu Mar  1 13:27:50 2018

@author: Will Long
"""

import math
import numpy as np
import pandas as pd
import scipy.optimize as sop
import matplotlib as mpl
import scipy.stats as stats 
from matplotlib import cm
from VarGamma import fit_ml, pdf, pdf_one_point, cdf_one_point,neg_log_likelihood,fit_moments
import matplotlib.pyplot as plt
import csv
import datetime
from statsmodels.distributions.empirical_distribution import ECDF
mpl.rcParams['font.family'] = 'serif'
from scipy.integrate import quad
from scipy.optimize import minimize
from matplotlib.ticker import LinearLocator, FormatStrFormatter
from mpl_toolkits.mplot3d import Axes3D
from NIG_valuation_FFT import NIG_value_call_FFT
from sympy.solvers import solve
from sympy import Symbol
from scipy.optimize import fsolve

#Taking the raw data and getting the daily returns

SP_raw = pd.read_excel('C:/Users/Will Long/Dropbox/HW Spring 2018/FINN6212/Project/GSPC.xlsx')

SP_raw['returns'] = 0.0

for row, coin in SP_raw.iterrows():
    e = (coin['Open']-coin['Close'])/coin['Open']
    SP_raw.loc[row, 'returns'] = e

er = SP_raw['returns']
SP = sorted(er)
N = len(SP)

r = 0.05 #risk-free rate

# Finding the Variance Gamma paraters 


def goal_fun(x):
    if (x[3] > 0) and (x[1] > 0) and (x[1] > abs(x[2]) > 0):
        return neg_log_likelihood(er, x)
    else:
        return np.Inf 
par_init = np.array( fit_moments(er) )
res = minimize(goal_fun, par_init, options={'disp': True}  )


#par = fit_ml(er) 
par = res.x
c = par[0]
sigma = par[1]
theta = par[2]
nu = par[3]  

hess_er = res.hess_inv  
std_err =[]
for i in range(0,len(hess_er[0])):
    se=(hess_er[i][i])**0.5
    std_err.append(se)

t_value = []
for i in range(0,len(std_err)):
    t_value.append(par[i]/std_err[i])

# Testing the good-ness of fit. 
nk = 15 # size of each group for the chi
Xo = np.array_split(SP, nk)
Xp = []
for i in range(0, nk-1):
    xi = list(Xo[i])
    C1 = cdf_one_point(xi[0], c, sigma, theta, nu)
    C2 = cdf_one_point(xi[len(xi)-1], c, sigma, theta, nu)
    
    p = N*(C2-C1)
    Xp.append(p)
    
Xobs = []
for i in range(0, nk-1):
    p = len(list(Xo[i]))
    Xobs.append(p)
    
chi = stats.chisquare(Xobs, Xp, len(par))
chi1 = stats.chisquare(Xobs, Xp)

# I'm not sure if I'm doing this right
cdf_SP = [cdf_one_point(x, c, sigma, theta, nu) for x in SP] 
def ecdf(x):
    xs = np.sort(x)
    ys = np.arange(1, len(xs)+1)/float(len(xs))
    return xs, ys

ecdf_SP = ecdf(SP)[1]

KS = stats.ks_2samp(ecdf_SP, cdf_SP)


# We need to find the risk netural parm


def VG_RN(c, sigma, theta, nu):
    lam = 1/nu
    alpha = (2/(nu*sigma**2)+theta**2/sigma**4)**0.5
    e = np.exp((r-c)/lam)
    betaRN = (((-2*alpha**2*e+alpha**2*e**2+alpha**2+e)**0.5)-e)/(e-1)
    sigmaRN = (abs(2/(nu*(alpha**2-betaRN**2))))**0.5
    thetaRN = betaRN*sigmaRN**2
    return [r, sigmaRN, thetaRN, nu]
et =np.exp((c+r)*nu)
nuRN=1/(sigma**2*(et-1))*((nu*abs(sigma**4*nu*et+4*sigma**2*et-2*sigma**2*et**2 \
     -2*theta**2*nu*et+theta**2*nu*et**2-2*sigma**2+theta**2*nu))**0.5+ \
     theta*nu*et+sigma**2+sigma**2*nu-theta*nu)
''' 
def VG_RN1(r, sigma, theta, nu):
    e = np.exp(r*nu)
    a = 1/(2*sigma**2*nu*(e-1))
    b = 2*(sigma**2*e+2*theta*e-2*theta)
    c = nu**2*(2*sigma**2*e+2*theta*e-2*theta)**2-4*sigma**2*nu*(e-1)*(sigma**2*nu*e+2*theta*nu*e-2*e+2)
    d = c**0.5-nu *b
    h = a*d
    sigmaRN = sigma*abs(h)
    thetaRN = theta*h
    return [h, sigmaRN, thetaRN]

def VG_RN2(r, sigma, theta, nu): 
    func = lambda x: ((1-nu*(x+1)*theta-0.5*sigma**2*nu*(x+1)**2)**(-1/nu)/(1-nu*(x)*theta-0.5*sigma**2*nu*(x)**2)**(-1/nu))-np.exp(r)
    
    
    h_i = VG_RN1(r, sigma, theta, nu)[0]
    h = fsolve(func, h_i)[0]
    sigmaRN = sigma*abs(h)
    thetaRN = theta*h
    return [h, sigmaRN, thetaRN]
 '''   

#Compare to the normal dist

NormVari = np.mean( (er-np.mean(er))**2 )
NormMeani = np.mean(er)
NormPari = [NormMeani, NormVari]

def normpdf_one_point(x=0.0, mean=0.0, var=1.0):
    
    pi = 3.1415926
    denom = (2*pi*var)**.5
    num = math.exp(-(float(x)-float(mean))**2/(2*var))
    return num/denom

def normpdf(x=0.0, mean=0.0, var=1.0):
	''' NIG probability density function of an array or a point x '''
	if isinstance(x, (int, float, np.double)): # works with lists and arrays
		return normpdf_one_point(x, mean, var)
	else:
		return map(lambda x: normpdf_one_point(x, mean=0.0, var=1.0), x)

def cdf_norm_one_point(x=0.0, mu=0.0, var=1.0):
	''' Norm cumulative distribution function in a point x '''
	return quad(lambda x: normpdf(x, mu, var), -100, x, epsabs=1e-10)[0]

def neg_log_likelihood_N(data, par):
	''' negative log likelihood function for Normal distribution '''
	# par = array([c, sigma, theta, nu])
	if (par[1] > 0):
		return -sum(np.log( list(normpdf(data, mean=par[0], var=par[1]) )))
	else:
		return np.Inf
def goal_fun_N(x):
    if (x[1] > 0):
        return neg_log_likelihood_N(SP, x)
    else:
        return np.Inf 

resN = minimize(goal_fun_N, NormPari, options={'disp': True}  )
NormPar = resN.x

NormVar = NormPar[1]
NormMean = NormPar[0]

hess_ern = resN.hess_inv  
std_errn =[]
for i in range(0,len(hess_ern[0])):
    se=(hess_ern[i][i])**0.5
    std_errn.append(se)

t_valuen = []
for i in range(0,len(std_errn)):
    t_valuen.append(NormPar[i]/std_errn[i])
XpN = []
for i in range(0, nk-1):
    xi = list(Xo[i])
    C1 = cdf_norm_one_point(xi[0], NormMean, NormVar)
    C2 = cdf_norm_one_point(xi[len(xi)-1], NormMean, NormVar)
    
    p = N*(C2-C1)
    XpN.append(p)

chiN = stats.chisquare(Xobs, XpN)

cdf_SP_N = [cdf_norm_one_point(x, NormMean, NormVar) for x in SP]

KSN = stats.ks_2samp(ecdf_SP, cdf_SP_N)

#Ploting the daily returns



nbins = 30 # number of bins
bins = np.linspace(SP[0], SP[N-1], nbins)

y = [pdf_one_point(x, c, sigma, theta, nu) for x in SP]
yn = [normpdf(x, NormMean, NormVar) for x in SP]
plt.hist(er, bins)
plt.plot(SP, y, 'b-.', lw=2.5) 
plt.plot(SP, yn, 'r-.', lw=2.5)