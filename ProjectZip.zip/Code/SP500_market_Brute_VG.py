# -*- coding: utf-8 -*-
"""
Created on Tue Mar 27 18:48:58 2018

@author: Will Long
"""


import math
import numpy as np
import pandas as pd
import scipy.optimize as sop
import matplotlib as mpl
import scipy.stats as stats 
from matplotlib import cm
from NIG import fit_ml, pdf, pdf_one_point, cdf_one_point
import matplotlib.pyplot as plt
import csv
import datetime
from statsmodels.distributions.empirical_distribution import ECDF
mpl.rcParams['font.family'] = 'serif'
from scipy.integrate import quad
from scipy.optimize import minimize
from matplotlib.ticker import LinearLocator, FormatStrFormatter
from mpl_toolkits.mplot3d import Axes3D
from NIG_valuation_FFT import NIG_value_call_FFT
from NIG_option_valuation_FOU import NIG_call_value_INT
from VG_option_valuation_FOU import VG_call_value_INT
from BSM_option_valuation import BSM_call_value 

# compare to market value

scalls = pd.read_excel('C:/Users/Will Long/Dropbox/HW Spring 2018/FINN6212/spxcalls20160331F.xlsx')
S0 = 2059.74
r = 0.05
tol = 0.2


'''
options1 = scalls[(np.abs(scalls['strike']-S0) / S0) < tol]

for row, option in options1.iterrows():
    e = datetime.datetime.strptime(str(option.loc['exdate']), "%Y%m%d")
    s = datetime.datetime.strptime(str(option.loc['date']), "%Y%m%d")
    if 5 < (e - s).days <= 8: options1.loc[row, 'T'] = (e - s).days / 365. 
    
    
    if 12 < (e - s).days <= 16: options1.loc[row, 'T'] = (e - s).days / 365.
    if 25 < (e - s).days <= 35: options1.loc[row, 'T'] = (e - s).days / 365.
    if 55 < (e - s).days <= 65: options1.loc[row, 'T'] = (e - s).days / 365.
    if 85 < (e - s).days <= 95: options1.loc[row, 'T'] = (e - s).days / 365.
    
    
    options1.loc[row, 'mean_offer'] = (option.loc['best_bid'] + option.loc['best_offer'])/2
   
options = options1[options1['T'] > 0]   
'''
options = scalls   

def NIG_error_function_FFT(p0):
    ''' Error Function for parameter calibration in NIG Model via
    Carr-Madan (1999) FFT approach.
    Parameters
    ==========
    sigma: float
    volatility factor in diffusion term
    lamb: float
    jump intensity
    mu: float
    expected jump size
    delta: float
    standard deviation of jump
    Returns
    =======
    RMSE: float
    root mean squared error
    ''' 
    
    alpha, beta, delta = p0
    if alpha < 0.0 or delta < 0.0 or (abs(alpha)-abs(beta)) < 0.0 or abs(alpha)-abs(beta+1)< 0.0 :
        return 500.0
    se = []
    for row, option in options.iterrows():
        
        T = option.loc['T']
        model_value = NIG_value_call_FFT(S0, option.loc['strike'], T/365,
                                         r, alpha, beta, delta)
        se.append((model_value - option.loc['mean_offer']) ** 2)
    RMSE = math.sqrt(sum(se) / len(se))
    
    
    return RMSE

def NIG_error_function_FOU(p0):
    ''' Error Function for parameter calibration in NIG Model via
    Carr-Madan (1999) FFT approach.
    Parameters
    ==========
    sigma: float
    volatility factor in diffusion term
    lamb: float
    jump intensity
    mu: float
    expected jump size
    delta: float
    standard deviation of jump
    Returns
    =======
    RMSE: float
    root mean squared error
    ''' 
    
    alpha, beta, delta = p0
    if alpha < 0.0 or delta < 0.0 or (abs(alpha)-abs(beta)) < 0.0 or abs(alpha)-abs(beta+1)< 0.0 :
        return 500.0
    se = []
    for row, option in options.iterrows():
        
        T = option.loc['T']
        model_value = NIG_call_value_INT(S0, option.loc['strike'], T/365,
                                         r, alpha, beta, delta)
        se.append((model_value - option.loc['mean_offer']) ** 2)
    RMSE = math.sqrt(sum(se) / len(se))
    
    
    return RMSE

def VG_error_function_FOU(p0):
    ''' Error Function for parameter calibration in NIG Model via
    Carr-Madan (1999) FFT approach.
    Parameters
    ==========
    sigma: float
    volatility factor in diffusion term
    lamb: float
    jump intensity
    mu: float
    expected jump size
    delta: float
    standard deviation of jump
    Returns
    =======
    RMSE: float
    root mean squared error
    ''' 
    
    sigma, theta, nu = p0
    alpha = (2/(nu*sigma**2)+theta**2/sigma**4)**0.5
    beta = theta/sigma**2
    if alpha < 0.0 or nu < 0.0 or (abs(alpha)-abs(beta)) < 0.0 or abs(alpha)-abs(beta+1)< 0.0 :
        return 500.0
    se = []
    for row, option in options.iterrows():
        
        T = option.loc['T']
        model_value = VG_call_value_INT(S0, option.loc['strike'], T/365,
                                         r, sigma, theta, nu)
        se.append((model_value - option.loc['mean_offer']) ** 2)
    RMSE = math.sqrt(sum(se) / len(se))
    
    
    return RMSE

def generate_plot(opt, options):
    #
    # Calculating Model Prices
    #
    alpha, beta, delta = opt
    
    for row, option in options.iterrows():
        
        T = option.loc['T']
        options.loc[row, 'Model'] = NIG_value_call_FFT(S0, option.loc['strike'],
                   T/365, r, alpha, beta, delta)
    #
    # Plotting
    #
    mats = sorted(set(options['exdate']))
    options = options.set_index('strike')
    for i, mat in enumerate(mats):
        options[options['exdate'] == mat][['mean_offer', 'Model']].\
            plot(style=['b-', 'ro'], title='%s' % str(mat)[:10])
        plt.ylabel('option value')
        plt.savefig('../images/08_NIG/NIG_calibration_3_%s.pdf' % i)
        
        
        
# Market based calibration 

param_init = [0.02, -0.05, 0.8] 



bnds = ((0.0, 2.0), (-2.0, 2.0), (0.0, 2.0))  

res = minimize(VG_error_function_FOU, param_init, method='SLSQP', bounds = bnds, options={'disp': True})    


print(res)


    

'''
if __name__ == '__main__':
    #
    # Calibration
    #
    i = 0 # counter initialization
    min_RMSE = 100 # minimal RMSE initialization
    p0 = sop.brute(NIG_error_function_FFT, ((0.0, 40.0, 0.1),
                                            (-40.0, 40.0, 0.1), (0.0, 1.0, 0.1) ), finish=None)
    # p0 = [0.15, 0.2, -0.3, 0.2]
    opt = sop.fmin(NIG_error_function_FFT, p0,
                   maxiter=500, maxfun=750,
                   xtol=0.000001, ftol=0.000001)
'''

def BSM_error_function_FFT(p0):
    ''' Error Function for parameter calibration in NIG Model via
    Carr-Madan (1999) FFT approach.
    Parameters
    ==========
    sigma: float
    volatility factor in diffusion term
    lamb: float
    jump intensity
    mu: float
    expected jump size
    delta: float
    standard deviation of jump
    Returns
    =======
    RMSE: float
    root mean squared error
    ''' 
    
    var = p0
    if  var < 0.0 :
        return 500.0
    se = []
    for row, option in options.iterrows():
        
        T = option.loc['T']
        model_value = BSM_call_value(S0, option.loc['strike'], 0, T,
                                         r, var)
        se.append((model_value - option.loc['mean_offer']) ** 2)
    RMSE = math.sqrt(sum(se) / len(se))
    return RMSE



