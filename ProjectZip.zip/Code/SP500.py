# -*- coding: utf-8 -*-
"""
Created on Thu Mar  1 13:27:50 2018

@author: Will Long
"""

import math
import numpy as np
import pandas as pd
import scipy.optimize as sop
import matplotlib as mpl
import scipy.stats as stats 
from matplotlib import cm
from NIG import fit_ml, pdf, pdf_one_point, cdf_one_point,neg_log_likelihood,fit_moments
from VarGamma import pdf_one_point as vg_pdf_one_point
import matplotlib.pyplot as plt
import csv
import datetime
from statsmodels.distributions.empirical_distribution import ECDF
mpl.rcParams['font.family'] = 'serif'
from scipy.integrate import quad
from scipy.optimize import minimize
from matplotlib.ticker import LinearLocator, FormatStrFormatter
from mpl_toolkits.mplot3d import Axes3D
from NIG_valuation_FFT import NIG_value_call_FFT


#Taking the raw data and getting the daily returns

SP_raw = pd.read_excel('C:/Users/Will Long/Dropbox/HW Spring 2018/FINN6212/Project/GSPC.xlsx')

SP_raw['returns'] = 0.0

for row, coin in SP_raw.iterrows():
    e = (coin['Open']-coin['Close'])/coin['Open']
    SP_raw.loc[row, 'returns'] = e

er = SP_raw['returns']
SP = sorted(er)
N = len(SP)

r = 0.05 #risk-free rate

# Finding the Variance Gamma paraters 


def goal_fun(x):
    if (x[3] > 0) and (x[1] > 0) and (x[1] > abs(x[2]) > 0):
        return neg_log_likelihood(er, x)
    else:
        return np.Inf 
par_init = np.array( fit_moments(er) )
res = minimize(goal_fun, par_init, options={'disp': True}  )


#par = fit_ml(er) 
par = res.x
mu = par[0]
alpha = par[1]
beta = par[2]
delta = par[3]  

hess_er = res.hess_inv  
std_err =[]
for i in range(0,len(hess_er[0])):
    se=(hess_er[i][i])**0.5
    std_err.append(se)

t_value = []
for i in range(0,len(std_err)):
    t_value.append(par[i]/std_err[i])

# Testing the good-ness of fit. 
nk = 15 # size of each group for the chi
Xo = np.array_split(SP, nk)
Xp = []
for i in range(0, nk-1):
    xi = list(Xo[i])
    C1 = cdf_one_point(xi[0], mu, alpha, beta, delta)
    C2 = cdf_one_point(xi[len(xi)-1], mu, alpha, beta, delta)
    
    p = N*(C2-C1)
    Xp.append(p)
    
Xobs = []
for i in range(0, nk-1):
    p = len(list(Xo[i]))
    Xobs.append(p)
    
chi = stats.chisquare(Xobs, Xp, len(par))
chi1 = stats.chisquare(Xobs, Xp)

# I'm not sure if I'm doing this right
cdf_SP = [cdf_one_point(x, mu, alpha, beta, delta) for x in SP] 
def ecdf(x):
    xs = np.sort(x)
    ys = np.arange(1, len(xs)+1)/float(len(xs))
    return xs, ys

ecdf_SP = ecdf(SP)[1]

KS = stats.ks_2samp(ecdf_SP, cdf_SP)


# We need to find the risk netural parm

betaRN = -1/2*(delta**4+(delta*r)**2+r*(-1*delta**2*(delta**2+r**2)*(delta**2+r**2-4*delta**2*alpha**2))**0.5)/(delta**2*(delta**2+r**2))
mur = r-mu
betaRN1 = -1/2*(delta**4+(delta*mur)**2+mur*(-1*delta**2*(delta**2+mur**2)*(delta**2+mur**2-4*delta**2*alpha**2))**0.5)/(delta**2*(delta**2+mur**2))


parRN = [r, alpha, betaRN, delta]
parRN1 = [r, alpha, betaRN1, delta]



#Compare to the normal dist

NormVar = np.mean( (er-np.mean(er))**2 )
NormMean = np.mean(er)
NormPar = [NormMean, NormVar]

def normpdf_one_point(x=0.0, mean=0.0, var=1.0):
    
    pi = 3.1415926
    denom = (2*pi*var)**.5
    num = math.exp(-(float(x)-float(mean))**2/(2*var))
    return num/denom

def normpdf(x=0.0, mean=0.0, var=1.0):
	''' NIG probability density function of an array or a point x '''
	if isinstance(x, (int, float, np.double)): # works with lists and arrays
		return normpdf_one_point(x, mean, var)
	else:
		return map(lambda x: normpdf_one_point(x, mean=0.0, var=1.0), x)

def cdf_norm_one_point(x=0.0, mu=0.0, var=1.0):
	''' Norm cumulative distribution function in a point x '''
	return quad(lambda x: normpdf(x, mu, var), -100, x, epsabs=1e-10)[0]


XpN = []
for i in range(0, nk-1):
    xi = list(Xo[i])
    C1 = cdf_norm_one_point(xi[0], NormMean, NormVar)
    C2 = cdf_norm_one_point(xi[len(xi)-1], NormMean, NormVar)
    
    p = N*(C2-C1)
    XpN.append(p)

chiN = stats.chisquare(Xobs, XpN)

cdf_SP_N = [cdf_norm_one_point(x, NormMean, NormVar) for x in SP]

KSN = stats.ks_2samp(ecdf_SP, cdf_SP_N)

#Ploting the daily returns
c=-0.00057533614447885853
sigma=0.0097829407962881695
theta=0.0006463433420541095
nu=0.82745807048234543


nbins = 30 # number of bins
bins = np.linspace(SP[0], SP[N-1], nbins)

y = [pdf_one_point(x, mu, alpha, beta, delta) for x in SP]
yn = [normpdf(x, NormMean, NormVar) for x in SP]
yvg = [vg_pdf_one_point(x, c, sigma, theta, nu) for x in SP]
plt.hist(er, bins)
plt.plot(SP, y, 'b-.', lw=2.5, label='NIG') 
plt.plot(SP, yn, 'r-.', lw=2.5, label='Normal')
plt.plot(SP, yvg, 'c-.', lw=2.5, label='VG')
plt.legend(loc=0)
#plt.savefig('C:/Users/Will Long/Dropbox/Will Long Project Finn6212/Charts/SP500.png')